# How to run
1. open the terminal
2. enter 'npm install' to install the pakages
3. enter 'npm run dev' to run the applcation



