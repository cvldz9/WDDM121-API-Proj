import "./News.css";

function News() {
	return (
		<>
			<div>News</div>
			<div></div>

			<img src="" alt="" />
			<audio src=""></audio>
		</>
	);
}

export default News;
